const conversations = [
    {
        id: 1,
        recipient: "John Snow",
        lastMessage: "Hi! How are you?",
        timestamp: "2024-02-22T14:20:00Z"
    },
    {
        id: 2,
        recipient: "Jane Mary",
        lastMessage:"when are you leaving for the event"
    }

    
]

